// import MosaicApp from "./mosaicApp";

window.onload = () => {
    const app = new MosaicApp();
    app.start();
};